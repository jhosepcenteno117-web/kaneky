from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from kaneki.assistant import KanekiAssistant

if __name__ == "__main__":
    bot = KanekiAssistant(ROOT)
    mode = "modelo entrenado" if bot.model is not None else "modo híbrido local"
    print(f"Kaneki V2.0 listo ({mode}). Escribe 'salir' para cerrar.\n")
    while True:
        q = input("Tú: ").strip()
        if q.lower() in {"salir", "exit", "quit"}:
            break
        print("Kaneki:", bot.reply(q), "\n")
