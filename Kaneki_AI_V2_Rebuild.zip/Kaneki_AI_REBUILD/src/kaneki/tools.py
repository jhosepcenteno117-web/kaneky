import ast
import datetime as dt
import json
import operator as op
import re
import unicodedata
import urllib.parse
import urllib.request

try:
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
except Exception:  # pragma: no cover
    ZoneInfo = None
    ZoneInfoNotFoundError = Exception

_ALLOWED_BIN = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.FloorDiv: op.floordiv, ast.Mod: op.mod, ast.Pow: op.pow}
_ALLOWED_UNARY = {ast.UAdd: op.pos, ast.USub: op.neg}


def safe_calculate(expr: str):
    expr = expr.replace("×", "*").replace("÷", "/").replace("^", "**")
    if len(expr) > 100: raise ValueError("Expresión demasiado larga")
    def ev(node):
        if isinstance(node, ast.Expression): return ev(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)): return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BIN:
            left, right = ev(node.left), ev(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 12: raise ValueError("Exponente demasiado grande")
            if isinstance(node.op, (ast.Div, ast.FloorDiv, ast.Mod)) and right == 0: raise ValueError("División por cero")
            return _ALLOWED_BIN[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARY: return _ALLOWED_UNARY[type(node.op)](ev(node.operand))
        raise ValueError("Operación no permitida")
    return ev(ast.parse(expr, mode="eval"))


def detect_calculation(text: str):
    lower = text.lower().strip()
    m = re.search(r"(?:cu[aá]nto es|calcula|resultado de)?\s*([-+*/().\d\s×÷^]+)\s*\??$", lower)
    if not m: return None
    expr = m.group(1).strip()
    if not any(ch.isdigit() for ch in expr) or not any(ch in expr for ch in "+-*/×÷^"): return None
    try: return safe_calculate(expr)
    except Exception: return None


def _norm(s):
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"\s+", " ", s).strip()


def _spanish_date(now):
    meses = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"]
    dias = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]
    return f"{dias[now.weekday()]}, {now.day} de {meses[now.month-1]} de {now.year}"


# Fast path for frequent locations. The generic fallback below handles cities
# not in this table via geocoding + timezonefinder when available.
TZ_ALIASES = {
    "peru": ("America/Lima", "Perú"), "lima": ("America/Lima", "Lima"), "huaral": ("America/Lima", "Huaral"),
    "espana": ("Europe/Madrid", "España peninsular"), "madrid": ("Europe/Madrid", "Madrid"), "barcelona": ("Europe/Madrid", "Barcelona"), "sevilla": ("Europe/Madrid", "Sevilla"), "valencia": ("Europe/Madrid", "Valencia"),
    "islas canarias": ("Atlantic/Canary", "Islas Canarias"), "canarias": ("Atlantic/Canary", "Islas Canarias"),
    "mexico": ("America/Mexico_City", "Ciudad de México"), "ciudad de mexico": ("America/Mexico_City", "Ciudad de México"),
    "argentina": ("America/Argentina/Buenos_Aires", "Argentina"), "buenos aires": ("America/Argentina/Buenos_Aires", "Buenos Aires"),
    "chile": ("America/Santiago", "Chile"), "santiago": ("America/Santiago", "Santiago de Chile"),
    "colombia": ("America/Bogota", "Colombia"), "bogota": ("America/Bogota", "Bogotá"), "ecuador": ("America/Guayaquil", "Ecuador continental"),
    "venezuela": ("America/Caracas", "Venezuela"), "nueva york": ("America/New_York", "Nueva York"), "los angeles": ("America/Los_Angeles", "Los Ángeles"), "miami": ("America/New_York", "Miami"),
    "reino unido": ("Europe/London", "Reino Unido"), "londres": ("Europe/London", "Londres"), "francia": ("Europe/Paris", "Francia"), "paris": ("Europe/Paris", "París"),
    "alemania": ("Europe/Berlin", "Alemania"), "berlin": ("Europe/Berlin", "Berlín"), "italia": ("Europe/Rome", "Italia"), "roma": ("Europe/Rome", "Roma"),
    "japon": ("Asia/Tokyo", "Japón"), "tokio": ("Asia/Tokyo", "Tokio"), "corea del sur": ("Asia/Seoul", "Corea del Sur"), "seul": ("Asia/Seoul", "Seúl"),
    "china": ("Asia/Shanghai", "China"), "pekin": ("Asia/Shanghai", "Pekín"), "sidney": ("Australia/Sydney", "Sídney"),
}


def _zone_now(zone):
    if ZoneInfo is not None:
        try: return dt.datetime.now(ZoneInfo(zone))
        except (ZoneInfoNotFoundError, KeyError, OSError): pass
    if zone == "America/Lima": return dt.datetime.now(dt.timezone(dt.timedelta(hours=-5)))
    return None


def current_year_answer(text: str):
    q = _norm(text)
    patterns = ["en que ano estamos", "que ano es", "cual es el ano actual", "en que ano nos encontramos", "ano actual"]
    if any(p in q for p in patterns):
        return f"Estamos en el año {dt.datetime.now().year}."
    return None


def _extract_time_place(text: str):
    q = _norm(text).strip(" ?!.,")
    # Do not mistake "a qué hora es..." as a location fragment.
    patterns = [
        r"(?:que hora es|que hora son|a que hora es|a que hora son|hora actual)\s+(?:ahora\s+)?(?:en|de)\s+(.+)$",
        r"(?:hora en|hora de)\s+(.+)$",
    ]
    for p in patterns:
        m = re.search(p, q)
        if m:
            place = m.group(1).strip(" ?!.,")
            if place and place not in {"mi pc", "mi computadora", "este equipo", "aqui"}:
                return place
    return None


def _geocode_timezone(place: str, timeout=4.0):
    """Resolve arbitrary city/country names when optional timezonefinder exists."""
    try:
        from timezonefinder import TimezoneFinder
    except Exception:
        return None
    try:
        params = urllib.parse.urlencode({"q": place, "format": "jsonv2", "limit": 1, "accept-language": "es"})
        req = urllib.request.Request("https://nominatim.openstreetmap.org/search?" + params, headers={"User-Agent": "KanekiAI-Rebuild/2.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
        if not data:
            return None
        lat, lon = float(data[0]["lat"]), float(data[0]["lon"])
        zone = TimezoneFinder(in_memory=True).timezone_at(lat=lat, lng=lon)
        if not zone:
            return None
        label = (data[0].get("display_name") or place).split(",")[0].strip() or place.title()
        return zone, label
    except Exception:
        return None


def date_time_answer(text: str):
    q = _norm(text)
    wants_time = any(k in q for k in ["que hora", "hora actual", "la hora", "a que hora", "que horas", "hora en "])
    wants_date = any(k in q for k in ["que fecha", "que dia", "fecha de hoy", "dia de hoy"])
    if not (wants_time or wants_date): return None

    matched = None
    for alias in sorted(TZ_ALIASES, key=len, reverse=True):
        if re.search(rf"\b{re.escape(alias)}\b", q):
            matched = TZ_ALIASES[alias]
            break
    place_query = _extract_time_place(text) if wants_time else None
    if matched is None and place_query:
        matched = _geocode_timezone(place_query)

    if matched:
        now = _zone_now(matched[0])
        if now is None: return None
        place = f"en {matched[1]}"
    else:
        # If the user explicitly named a place but it could not be resolved,
        # returning the computer clock would be misleading.
        if place_query:
            return f"No pude resolver la zona horaria de {place_query.title()} con seguridad."
        now = dt.datetime.now().astimezone(); place = "según la hora de este equipo"

    if wants_time and wants_date: return f"Son las {now.strftime('%H:%M')} {place}. Hoy es {_spanish_date(now)}."
    if wants_time: return f"Son las {now.strftime('%H:%M')} {place}."
    return f"Hoy es {_spanish_date(now)}."
