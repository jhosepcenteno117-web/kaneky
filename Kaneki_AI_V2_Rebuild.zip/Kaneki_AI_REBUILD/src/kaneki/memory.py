import json
from pathlib import Path
from datetime import datetime


class MemoryStore:
    """Memoria local y persistente. No envía datos fuera del equipo."""

    def __init__(self, path):
        self.path = Path(path)
        self.data = {"facts": [], "preferences": {}, "updated_at": None}
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                self.data.update(raw)
        except Exception:
            # Si el archivo se corrompe, Kaneki sigue funcionando sin memoria.
            pass

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data["updated_at"] = datetime.now().isoformat(timespec="seconds")
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    @property
    def facts(self):
        return self.data.setdefault("facts", [])

    def remember(self, text):
        clean = " ".join(text.strip().split())
        if not clean:
            return False
        if clean.lower() not in [x.lower() for x in self.facts]:
            self.facts.append(clean)
            self.facts[:] = self.facts[-100:]
            self._save()
        return True

    def forget_all(self):
        self.data = {"facts": [], "preferences": {}, "updated_at": None}
        self._save()

    def summary(self, limit=12):
        if not self.facts:
            return "Aún no tengo recuerdos guardados sobre ti. Puedes decirme: 'recuerda que ...'."
        lines = ["Esto es lo que recuerdo de ti:"]
        for item in self.facts[-limit:]:
            lines.append(f"• {item}")
        return "\n".join(lines)

    def prompt_context(self, limit=8):
        return "\n".join(f"- {x}" for x in self.facts[-limit:])
