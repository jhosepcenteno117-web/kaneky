import json
import re
from pathlib import Path
from .text_utils import normalize_text


class CoreKnowledge:
    def __init__(self, path):
        self.path = Path(path)
        self.entries = []
        if self.path.exists():
            try:
                self.entries = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                self.entries = []

    @staticmethod
    def _contains_alias_as_words(query: str, alias: str) -> bool:
        """Match aliases as complete words/phrases, never as substrings.

        This prevents aliases such as ``peru`` from matching ``peruanos``.
        """
        if not query or not alias:
            return False
        pattern = r"(?<![\wáéíóúüñ])" + re.escape(alias) + r"(?![\wáéíóúüñ])"
        return re.search(pattern, query, flags=re.IGNORECASE) is not None

    def lookup(self, text: str):
        q = normalize_text(text)
        best = None
        best_len = 0
        for entry in self.entries:
            for alias in entry.get("aliases", []):
                a = normalize_text(alias)
                if a and (q == a or self._contains_alias_as_words(q, a)):
                    if len(a) > best_len:
                        best = entry
                        best_len = len(a)
        return best
