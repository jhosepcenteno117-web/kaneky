from pathlib import Path
import datetime as dt
import json
import re
import torch

from .knowledge import KnowledgeBase
from .core_knowledge import CoreKnowledge
from .memory import MemoryStore
from .model import TinyGPT, GPTConfig
from .tokenizer import ByteTokenizer
from .tools import detect_calculation, date_time_answer, current_year_answer
from .text_utils import normalize_text
from .local_llm import OllamaClient
from .web_search import search_web, format_context
from .current_facts import answer_structured_current


class KanekiAssistant:
    VERSION = "2.0 Rebuild"

    def __init__(self, root_dir):
        self.root = Path(root_dir)
        self.kb = KnowledgeBase(self.root / "data" / "knowledge.jsonl")
        self.core = CoreKnowledge(self.root / "data" / "core_knowledge.json")
        self.memory = MemoryStore(self.root / "data" / "memory.json")
        self.tokenizer = ByteTokenizer()
        self.model = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.config = json.loads((self.root / "config.json").read_text(encoding="utf-8"))
        c = self.config.get("assistant", {})
        self.history = []
        self.max_history_turns = int(c.get("max_history_turns", 12))
        self.web_enabled = bool(c.get("web_lookup", True))
        self.llm_enabled = bool(c.get("local_llm_enabled", True))
        self.llm_model_name = c.get("local_llm_model", "qwen3:4b-instruct")
        self.llm_fallback_models = c.get("local_llm_fallback_models", ["qwen3:4b", "qwen2.5:3b"])
        self.llm_temperature = float(c.get("local_llm_temperature", 0.35))
        self.llm_num_ctx = int(c.get("local_llm_num_ctx", 8192))
        self.llm = OllamaClient(c.get("local_llm_url", "http://127.0.0.1:11434"), self.llm_model_name, c.get("local_llm_timeout_seconds", 90), c.get("ollama_keep_alive", "30m"))
        self.last_topic = None
        self.last_web_sources = []
        self._select_installed_llm()
        self._try_load_model()

    def _select_installed_llm(self):
        if not self.llm_enabled or not self.llm.is_available(): return
        picked = self.llm.choose_first_installed([self.llm_model_name] + list(self.llm_fallback_models))
        if picked:
            self.llm_model_name = picked

    def _try_load_model(self):
        ckpt = self.root / "checkpoints" / "kaneki.pt"
        if not ckpt.exists(): return
        try:
            data = torch.load(ckpt, map_location=self.device, weights_only=False)
            cfg = GPTConfig(**data["model_config"])
            model = TinyGPT(cfg); model.load_state_dict(data["model"]); model.to(self.device).eval(); self.model = model
        except Exception: self.model = None

    def clear_session(self):
        self.history.clear(); self.last_topic = None; self.last_web_sources = []

    def _add_history(self, user_text, answer):
        self.history.append((user_text, answer)); self.history[:] = self.history[-self.max_history_turns:]

    def _memory_intent(self, text):
        lower = normalize_text(text)
        for pattern in [r"^(?:recuerda|recorda|recuerda por favor)\s+(?:que\s+)?(.+)$", r"^(?:guarda|anota)\s+(?:que\s+)?(.+)$"]:
            m = re.match(pattern, lower, flags=re.IGNORECASE)
            if m:
                fact = m.group(1).strip().rstrip(".")
                if fact:
                    self.memory.remember(fact); return f"Lo guardé en mi memoria local: {fact}."
        if any(k in lower for k in ["que recuerdas de mi", "que sabes de mi"]): return self.memory.summary()
        if any(k in lower for k in ["borra todos tus recuerdos", "olvida todo lo que recuerdas", "borra tu memoria"]):
            self.memory.forget_all(); return "Borré la memoria local guardada de Kaneki."
        return None

    def _smalltalk(self, text):
        q = normalize_text(text).strip(" .?!")
        if q in {"hola", "buenas", "hey", "holi", "hola kaneki"}: return "Hola. Soy Kaneki. ¿En qué te ayudo?"
        if q in {"gracias", "muchas gracias", "thanks"}: return "De nada."
        if q in {"quien eres", "quien eres tu", "quien sos", "como te llamas", "cual es tu nombre"}:
            return "Soy Kaneki AI V2.0, tu asistente personal local. Converso con un modelo local, mantengo contexto, puedo recordar lo que me pidas y consultar la web cuando una pregunta necesita información actual o verificación."
        if q in {"como estas", "como te encuentras", "todo bien"}: return "Estoy listo para ayudarte."
        return None

    def _requested_count(self, text):
        q = normalize_text(text)
        m = re.search(r"\b(\d{1,2})\b", q)
        if m and 1 <= int(m.group(1)) <= 50: return int(m.group(1))
        words = {"dos":2,"tres":3,"cuatro":4,"cinco":5,"seis":6,"siete":7,"ocho":8,"nueve":9,"diez":10,"once":11,"doce":12,"quince":15,"veinte":20}
        for w,n in words.items():
            if re.search(rf"\b{w}\b", q): return n
        return None

    def _is_list_request(self, text):
        q = normalize_text(text)
        if self._requested_count(text): return True
        return q.startswith(("enumera ", "lista ", "nombra ", "menciona ", "haz una lista", "cuales son "))

    def _is_current_request(self, text):
        q = normalize_text(text)
        current = [
            "ultimo ", "ultima ", "ultimos ", "ultimas ", "actualmente", "actual ", "hoy",
            "reciente", "recientes", "este ano", "este año", "ahora mismo", "acaba de salir",
            "mas nuevo", "mas nueva", "más nuevo", "más nueva", "mejores valoraciones",
            "mejor valorados", "mejor valoradas", "ranking actual", "top actual"
        ]
        if any(k in q for k in current):
            return True
        # A request for the current/future calendar year needs live evidence.
        # Past years do not become "current" forever because of a hardcoded 2026.
        this_year = dt.datetime.now().year
        years = [int(y) for y in re.findall(r"\b20\d{2}\b", q)]
        if years and max(years) >= this_year:
            return True
        return False

    def _is_factoid_request(self, text):
        q = normalize_text(text)
        starters = ("quien ", "quien es ", "que es ", "cual ", "cuando ", "donde ", "en que ano ", "de que trata ", "cuando salio ", "cuando se estreno ", "cuantos ", "cuantas ")
        if q.startswith(starters): return True
        if any(x in q for x in [" en que ano salio", " fecha de lanzamiento", " cuando salio", " cuando se estreno"]): return True
        return False

    def _known_title(self, text):
        try:
            item = self.kb.find_title_in_text(text)
            if item: return item.get("title")
        except Exception: pass
        return None

    def _has_followup_ref(self, text):
        q = normalize_text(text)
        refs = ["ese juego", "este juego", "ese anime", "este anime", "esa pelicula", "esa película", "esa serie", "eso", "ese", "esa obra"]
        return any(r in q for r in refs)

    def _resolve_followup(self, text):
        if not self._has_followup_ref(text):
            return text
        if self.last_topic:
            return f"{self.last_topic}: {text}"
        if self.history:
            previous_user = self.history[-1][0]
            return f"Contexto de la pregunta anterior: {previous_user}. Pregunta actual: {text}"
        return text

    def _update_topic_from_input(self, text):
        title = self._known_title(text)
        if title:
            self.last_topic = title
            return
        # Conservador: extrae nombres después de marcadores de obras/productos.
        m = re.search(r"(?:juego|anime|pel[ií]cula|serie)\s+([A-Za-z0-9:._+'’ -]{3,70})", text, flags=re.I)
        if m:
            candidate = m.group(1).strip(" ?!.,")
            if len(candidate.split()) <= 8: self.last_topic = candidate

    def _web_query(self, text):
        resolved = self._resolve_followup(text)
        now = dt.datetime.now().astimezone()
        if self._is_current_request(resolved):
            return f"{resolved} {now.year}"
        return resolved

    def _should_use_web(self, text):
        if not self.web_enabled:
            return False
        resolved = self._resolve_followup(text)
        # Current/changing facts always need fresh evidence.
        if self._is_current_request(resolved):
            return True
        # A concrete release/air-date question needs verification when it refers
        # to a named title or an explicit follow-up. A completely unrelated
        # factoid (e.g. "quién es Lionel Messi") must NOT inherit the previous
        # topic just because history exists.
        q = normalize_text(resolved)
        date_fact = any(x in q for x in ["cuando salio", "cuando se estreno", "fecha de lanzamiento", "en que ano salio", "en que año salio"])
        if date_fact and (self._known_title(resolved) or self._has_followup_ref(text) or self.last_topic):
            return True
        return False

    def _search_context(self, text):
        if not self._should_use_web(text): return [], ""
        results = search_web(self._web_query(text), year=dt.datetime.now().year, limit=6, timeout=5.5)
        self.last_web_sources = results
        return results, format_context(results)

    def _local_context(self, text):
        try:
            scored = self.kb.search_scored(text, limit=4)
            return [item for conf, _, item in scored if conf >= 0.62]
        except Exception:
            return []

    def _system_prompt(self, text, local_items, web_context):
        now = dt.datetime.now().astimezone()
        memory = self.memory.prompt_context() or "Sin recuerdos guardados."
        local = "\n".join(f"- {x['title']}: {x['description']}" for x in local_items[:4]) or "Sin contexto local relevante."
        n = self._requested_count(text)
        list_rule = f"El usuario pidió {n} elementos: entrega exactamente {n} ítems pertinentes." if n else ("Si pide una lista, responde con una lista real." if self._is_list_request(text) else "")
        web_rule = ("Hay fuentes web relevantes debajo. Úsalas para cualquier dato cambiante o fecha concreta; no inventes lo que no aparezca respaldado." if web_context else "No hay evidencia web para esta respuesta; no digas que navegaste ni presentes datos cambiantes como verificados.")
        return (
            "Eres Kaneki, un asistente personal general en español. /no_think\n"
            "REGLA DE SALIDA: responde SOLO con la respuesta final para el usuario. Nunca muestres razonamiento interno, análisis, instrucciones, etiquetas <think>, ni frases como 'the user is asking', 'let me think', 'according to the instructions' o similares. "
            "Responde en español salvo que el usuario pida otro idioma. Sé natural: conversa como un asistente, no como un informe de depuración. "
            "Entiende la intención completa y el contexto de la conversación; no respondas por una sola palabra ni arrastres un tema anterior a una pregunta nueva sin una referencia explícita. "
            "Para hechos estables de cultura general puedes usar tu conocimiento. Para información cambiante (último producto, rankings, noticias, precios, estado actual) usa únicamente la evidencia web proporcionada. "
            "Si la evidencia web es insuficiente, dilo de forma breve y útil; no expongas el proceso de búsqueda ni enumeres resultados irrelevantes. "
            "No inventes fechas, nombres, lanzamientos, modelos ni puntuaciones. Si una fecha/hora del sistema aparece en este prompt, considérala autoritativa aunque tu entrenamiento sea anterior. "
            "No te confundas por el año actual: el presente de esta conversación es el indicado abajo. "
            f"Fecha/hora local del equipo: {now.isoformat(timespec='minutes')}. Año actual: {now.year}. "
            f"{list_rule} {web_rule}\n\n"
            f"Memoria útil del usuario:\n{memory}\n\n"
            f"Contexto local auxiliar (solo si encaja con la pregunta):\n{local}\n\n"
            f"Fuentes web relevantes, si existen:\n{web_context or 'Ninguna.'}"
        )

    def _messages(self, text, local_items, web_context):
        msgs = [{"role":"system", "content":self._system_prompt(text, local_items, web_context)}]
        for u,a in self.history[-self.max_history_turns:]:
            msgs += [{"role":"user","content":u},{"role":"assistant","content":a}]
        msgs.append({"role":"user","content":text + "\n/no_think"})
        return msgs

    def _count_items(self, answer):
        lines = [x.strip() for x in (answer or "").splitlines() if x.strip()]
        return sum(bool(re.match(r"^(?:\d{1,2}[.)]|[-•*])\s+", x)) for x in lines)

    def _repair_list(self, text, answer, local_items, web_context):
        n = self._requested_count(text)
        if not n or self._count_items(answer) >= n: return answer
        msgs = self._messages(text, local_items, web_context)
        msgs += [{"role":"assistant","content":answer or ""},{"role":"user","content":f"Corrige únicamente el formato y la cobertura: necesito exactamente {n} elementos pertinentes, numerados del 1 al {n}. No cambies de tema y no inventes datos."}]
        fixed = self.llm.chat(msgs, temperature=0.2, num_ctx=self.llm_num_ctx, think=False, num_predict=600)
        return fixed.strip() if fixed else answer

    def _strict_local_fallback(self, text):
        """Fallback offline conservador: solo entidades claramente preguntadas.

        La base local nunca responde listas amplias ni preguntas actuales.
        """
        if self._is_current_request(text) or self._is_list_request(text):
            return None
        q = normalize_text(text).strip(" .?!")
        direct = q.startswith(("quien es ", "que es ", "que sabes de ", "que sabes sobre ", "de que trata ", "cuentame sobre ", "hablame de "))
        if not direct:
            return None
        item = self.kb.find_title_in_text(text)
        if item:
            self.last_topic = item.get("title")
            return f"{item['title']} — {item['description']}"
        core = self.core.lookup(text)
        if core:
            # Solo aceptar si el alias aparece como entidad completa; CoreKnowledge ya usa límites de palabra.
            self.last_topic = core.get("title")
            return core.get("answer")
        return None

    def local_llm_status(self):
        if not self.llm_enabled: return {"enabled":False,"available":False,"installed":False,"model":self.llm_model_name}
        available = self.llm.is_available()
        installed = self.llm.model_installed(self.llm.model) if available else False
        return {"enabled":True,"available":available,"installed":installed,"model":self.llm.model,"preferred":self.config.get("assistant",{}).get("local_llm_model","qwen3:4b-instruct"),"error":self.llm.last_error}

    def _failure_message(self):
        if not self.llm.is_available():
            return "No pude conectar con Ollama en este momento. Ollama debe estar abierto para usar el cerebro local."
        if not self.llm.model_installed(self.llm.model):
            return f"Ollama está abierto, pero no encuentro el modelo {self.llm.model}. Ejecuta setup_local_brain.bat."
        return "No pude generar una respuesta fiable en este intento. Inténtalo de nuevo; no voy a inventar una respuesta para rellenar el espacio."

    def reply(self, text, on_token=None):
        text = text.strip()
        if not text: return "Escríbeme algo y te respondo."

        for handler in (self._memory_intent,):
            ans = handler(text)
            if ans: self._add_history(text, ans); return ans

        calc = detect_calculation(text)
        if calc is not None:
            ans = f"El resultado es {calc}."; self._add_history(text, ans); return ans

        for handler in (current_year_answer, date_time_answer):
            try: ans = handler(text)
            except Exception: ans = None
            if ans: self._add_history(text, ans); return ans

        ans = self._smalltalk(text)
        if ans: self._add_history(text, ans); return ans

        # Prefer structured APIs for dynamic rankings when available. This is
        # more reliable than asking a language model to infer rankings from
        # generic search snippets.
        if self.web_enabled:
            try:
                ans = answer_structured_current(text)
            except Exception:
                ans = None
            if ans:
                self._add_history(text, ans)
                if on_token is not None:
                    on_token(ans)
                return ans

        self._update_topic_from_input(text)
        local_items = self._local_context(self._resolve_followup(text))
        web_results, web_context = self._search_context(text)

        # Preguntas actuales sin resultados web: no fingimos actualidad usando memoria vieja del modelo.
        if self._is_current_request(text) and self.web_enabled and not web_results:
            ans = "No pude verificar información actual en la web en este momento. Prefiero no darte como actual un dato que podría estar desfasado."
            self._add_history(text, ans); return ans

        if not self.llm_enabled or not self.llm.is_available() or not self.llm.model_installed(self.llm.model):
            ans = self._strict_local_fallback(text) or self._failure_message()
            self._add_history(text, ans); return ans

        messages = self._messages(text, local_items, web_context)
        list_req = self._is_list_request(text)
        # Para listas verificamos el resultado antes de mostrarlo. Para conversación normal hacemos streaming.
        if list_req:
            ans = self.llm.chat(messages, temperature=0.30, num_ctx=self.llm_num_ctx, think=False, num_predict=700)
            if ans: ans = self._repair_list(text, ans.strip(), local_items, web_context)
            if ans and on_token is not None: on_token(ans)
        else:
            ans = self.llm.chat_stream(messages, temperature=self.llm_temperature, num_ctx=self.llm_num_ctx, on_token=on_token, think=False, num_predict=650) if on_token else self.llm.chat(messages, temperature=self.llm_temperature, num_ctx=self.llm_num_ctx, think=False, num_predict=650)

        if not ans:
            ans = self._failure_message()
        else:
            ans = ans.strip()
        self._add_history(text, ans)
        return ans
