class ByteTokenizer:
    """Tokenizer UTF-8 simple y entrenable sin dependencias externas."""
    BOS = 256
    EOS = 257
    PAD = 258
    vocab_size = 259

    def encode(self, text: str, add_bos: bool = False, add_eos: bool = False):
        ids = list(text.encode("utf-8", errors="replace"))
        if add_bos:
            ids = [self.BOS] + ids
        if add_eos:
            ids = ids + [self.EOS]
        return ids

    def decode(self, ids):
        raw = bytes(i for i in ids if 0 <= int(i) <= 255)
        return raw.decode("utf-8", errors="ignore")
