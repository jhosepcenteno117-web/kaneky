"""Structured online data sources for queries where search snippets are fragile."""
from __future__ import annotations

import json
import re
import urllib.request


def _norm(s):
    import unicodedata
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"\s+", " ", s).strip()


def anime_ranking_request(text: str):
    q = _norm(text)
    if "anime" not in q:
        return None
    if not any(k in q for k in ["valorad", "ranking", "puntuacion", "puntuación", "top", "mejores anime", "mejor anime"]):
        return None
    m = re.search(r"\b(20\d{2})\b", q)
    year = int(m.group(1)) if m else None
    c = re.search(r"\b(\d{1,2})\b", q)
    count = int(c.group(1)) if c else 10
    count = max(1, min(count, 20))
    return year, count


def anilist_top_anime(year: int, count: int, timeout=7.0):
    """Top anime that started in `year`, sorted by AniList average score."""
    query = r'''
    query ($page: Int, $perPage: Int, $start: FuzzyDateInt, $end: FuzzyDateInt) {
      Page(page: $page, perPage: $perPage) {
        media(type: ANIME, startDate_greater: $start, startDate_lesser: $end, sort: SCORE_DESC, isAdult: false) {
          title { romaji english }
          averageScore
          format
          season
          startDate { year month day }
          siteUrl
        }
      }
    }
    '''
    payload = json.dumps({
        "query": query,
        "variables": {"page": 1, "perPage": max(count, 10), "start": year * 10000, "end": (year + 1) * 10000},
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://graphql.anilist.co",
        data=payload,
        headers={"Content-Type": "application/json", "Accept": "application/json", "User-Agent": "KanekiAI-Rebuild/2.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
        media = data.get("data", {}).get("Page", {}).get("media", [])
        out = []
        for x in media:
            score = x.get("averageScore")
            if not score:
                continue
            title = ((x.get("title") or {}).get("english") or (x.get("title") or {}).get("romaji") or "").strip()
            if not title:
                continue
            out.append({"title": title, "score": score, "url": x.get("siteUrl") or "", "format": x.get("format") or ""})
            if len(out) >= count:
                break
        return out
    except Exception:
        return []


def answer_structured_current(text: str):
    req = anime_ranking_request(text)
    if req:
        year, count = req
        if year is None:
            return None
        rows = anilist_top_anime(year, count)
        if len(rows) >= min(count, 3):
            lines = [f"Según la puntuación media disponible en AniList, estos son {count} animes de {year} mejor valorados en este momento:"]
            for i, x in enumerate(rows[:count], 1):
                lines.append(f"{i}. {x['title']} — {x['score']}/100")
            lines.append("Las puntuaciones pueden cambiar conforme se añaden votos.")
            return "\n".join(lines)
    return None
