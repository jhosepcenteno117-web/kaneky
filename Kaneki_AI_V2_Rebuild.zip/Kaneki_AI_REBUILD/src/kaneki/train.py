import json
import os
import random
from pathlib import Path

import torch
from torch.utils.data import DataLoader, random_split

from .dataset import ByteBlockDataset
from .model import TinyGPT, GPTConfig
from .tokenizer import ByteTokenizer


def train(root_dir):
    root = Path(root_dir)
    cfg_all = json.loads((root / "config.json").read_text(encoding="utf-8"))
    mcfg = cfg_all["model"]
    tcfg = cfg_all["training"]

    seed = tcfg.get("seed", 1337)
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = ByteTokenizer()
    model_cfg = GPTConfig(vocab_size=tokenizer.vocab_size, **mcfg)
    model = TinyGPT(model_cfg).to(device)

    dataset = ByteBlockDataset(root / "data" / "train.txt", tokenizer, model_cfg.block_size)
    val_size = max(1, int(len(dataset) * 0.05))
    train_size = len(dataset) - val_size
    train_ds, val_ds = random_split(dataset, [train_size, val_size], generator=torch.Generator().manual_seed(seed))

    train_loader = DataLoader(train_ds, batch_size=tcfg["batch_size"], shuffle=True, drop_last=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=tcfg["batch_size"], shuffle=False, drop_last=False, num_workers=0)
    train_iter = iter(train_loader)

    opt = torch.optim.AdamW(model.parameters(), lr=tcfg["learning_rate"], betas=(0.9, 0.95), weight_decay=0.1)

    use_amp = device == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    print(f"Dispositivo: {device}")
    if device == "cuda":
        print("GPU:", torch.cuda.get_device_name(0))
    print(f"Parámetros del modelo: {model.parameter_count():,}")
    print(f"Bloques de entrenamiento: {len(train_ds):,}")

    def evaluate(max_batches):
        model.eval()
        losses = []
        with torch.no_grad():
            for i, (x, y) in enumerate(val_loader):
                if i >= max_batches:
                    break
                x, y = x.to(device), y.to(device)
                with torch.amp.autocast(device_type=device, enabled=use_amp):
                    _, loss = model(x, y)
                losses.append(loss.item())
        model.train()
        return sum(losses) / max(1, len(losses))

    max_steps = tcfg["max_steps"]
    eval_interval = tcfg["eval_interval"]
    ckpt_dir = root / "checkpoints"
    ckpt_dir.mkdir(exist_ok=True)

    model.train()
    for step in range(1, max_steps + 1):
        try:
            x, y = next(train_iter)
        except StopIteration:
            train_iter = iter(train_loader)
            x, y = next(train_iter)

        x, y = x.to(device), y.to(device)
        opt.zero_grad(set_to_none=True)
        with torch.amp.autocast(device_type=device, enabled=use_amp):
            _, loss = model(x, y)
        scaler.scale(loss).backward()
        scaler.unscale_(opt)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(opt)
        scaler.update()

        if step == 1 or step % 25 == 0:
            print(f"Paso {step:5d}/{max_steps} | train loss {loss.item():.4f}")

        if step % eval_interval == 0 or step == max_steps:
            val_loss = evaluate(tcfg["eval_iters"])
            print(f"  -> validación loss {val_loss:.4f}")
            torch.save({
                "model": model.state_dict(),
                "model_config": model_cfg.__dict__,
                "step": step,
                "val_loss": val_loss,
            }, ckpt_dir / "kaneki.pt")
            print("  -> checkpoint guardado en checkpoints/kaneki.pt")

    print("Entrenamiento terminado.")
