"""Web retrieval for Kaneki.

The previous build sent the literal user sentence to Bing. That made requests
such as "dime 5 animes..." rank pages about the English word/coin "dime".
This module creates search-engine queries from the *subject* of the request,
uses multiple targeted queries, filters irrelevant hits, and preserves source
URLs for grounding.
"""
from __future__ import annotations

import html
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass

from .web_lookup import wikipedia_summary

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) KanekiAI-Rebuild/2.0"


@dataclass
class SearchResult:
    title: str
    snippet: str
    url: str

    @property
    def domain(self):
        try:
            return urllib.parse.urlparse(self.url).netloc.replace("www.", "").lower()
        except Exception:
            return ""


def _clean_html(text):
    text = html.unescape(text or "")
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _norm(s):
    import unicodedata
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9+#. ]+", " ", s)


STOP = {
    "dime","decime","por","favor","cual","cuales","que","quien","quienes","es","son","el","la","los","las","un","una","unos","unas",
    "de","del","al","en","y","o","me","puedes","podrias","quiero","saber","salio","salieron","lanzado","lanzada","fue","ha","han",
    "mas","mejor","mejores","ultimo","ultima","ultimos","ultimas","actual","actualmente","hoy","ahora","con","sobre","para"
}


def subject_tokens(question: str):
    toks = [t for t in _norm(question).split() if len(t) > 1 and t not in STOP]
    # De-duplicate while preserving order.
    out = []
    for t in toks:
        if t not in out:
            out.append(t)
    return out[:10]


def build_search_queries(question: str, year: int):
    q = _norm(question)
    toks = subject_tokens(question)
    base = " ".join(toks) or question.strip()

    if "iphone" in q:
        return [
            f"site:apple.com iPhone latest released {year}",
            f"Apple latest iPhone released {year}",
            f"site:apple.com/newsroom iPhone {year}",
        ]
    if "samsung" in q and any(x in q for x in ("celular", "telefono", "galaxy", "smartphone", "ultimo", "ultima")):
        return [
            f"site:samsung.com Galaxy smartphone latest {year}",
            f"Samsung latest Galaxy phone released {year}",
            f"site:news.samsung.com Galaxy smartphone {year}",
        ]
    if "anime" in q and any(x in q for x in ("valorad", "ranking", "mejor", "top", str(year))):
        return [
            f"highest rated anime {year} MyAnimeList",
            f"top anime {year} AniList score",
            f"best rated anime {year}",
        ]
    if any(x in q for x in ("cuando salio", "fecha de lanzamiento", "en que ano salio", "cuando se estreno")):
        return [f"{base} release date", f"{base} lanzamiento"]
    return [f"{base} {year}" if str(year) not in base else base]


def bing_rss_search(query: str, limit=5, timeout=5.0):
    params = urllib.parse.urlencode({"q": query, "format": "rss", "setlang": "es"})
    url = "https://www.bing.com/search?" + params
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "es-ES,es;q=0.9,en;q=0.6"})
    out = []
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
        root = ET.fromstring(raw)
        for item in root.findall(".//item"):
            title = _clean_html(item.findtext("title"))
            link = (item.findtext("link") or "").strip()
            desc = _clean_html(item.findtext("description"))
            if title and link:
                out.append(SearchResult(title, desc[:700], link))
            if len(out) >= limit:
                break
    except Exception:
        return []
    return out


def _relevant(question: str, result: SearchResult):
    q = _norm(question)
    blob = _norm(result.title + " " + result.snippet + " " + result.domain)
    # Strong entity gates prevent "dime" -> Dime coin and similar disasters.
    gates = []
    if "iphone" in q: gates = ["iphone", "apple"]
    elif "samsung" in q: gates = ["samsung", "galaxy"]
    elif "anime" in q: gates = ["anime", "myanimelist", "anilist"]
    if gates and not any(g in blob for g in gates):
        return False
    toks = [t for t in subject_tokens(question) if len(t) >= 3 and not t.isdigit()]
    if not toks:
        return True
    def variants(t):
        out = {t}
        if t.endswith("es") and len(t) > 4:
            out.add(t[:-2])
        if t.endswith("s") and len(t) > 3:
            out.add(t[:-1])
        return out
    hits = sum(any(v in blob for v in variants(t)) for t in toks)
    # A strong entity gate is already quite selective. For other queries require
    # at least one subject-token overlap.
    return hits >= 1 or bool(gates)


def search_web(question: str, year: int, limit=6, timeout=5.0):
    out = []
    seen = set()
    queries = build_search_queries(question, year)
    per_query = max(3, min(5, limit))
    for query in queries:
        for r in bing_rss_search(query, limit=per_query, timeout=timeout):
            if r.url in seen or not _relevant(question, r):
                continue
            seen.add(r.url)
            out.append(r)
            if len(out) >= limit:
                return out
    # Wikipedia is a fallback for stable named entities, not a substitute for
    # current-product/ranking evidence.
    qn = _norm(question)
    currentish = any(x in qn for x in ("ultimo", "ultima", "actual", "hoy", "reciente", "ranking", "valorad"))
    if not out and not currentish:
        hit = wikipedia_summary(" ".join(subject_tokens(question)) or question, timeout=timeout)
        if hit:
            r = SearchResult(hit.get("title", "Wikipedia"), hit.get("summary", ""), "https://es.wikipedia.org/")
            if _relevant(question, r):
                out.append(r)
    return out


def format_context(results):
    lines = []
    for i, r in enumerate(results, 1):
        lines.append(f"[{i}] {r.title}\nFuente: {r.url}\nFragmento: {r.snippet}")
    return "\n\n".join(lines)
