import json
import re
import urllib.error
import urllib.request


_THINK_BLOCK = re.compile(r"<think>.*?</think>", re.IGNORECASE | re.DOTALL)
_META_PREFIX = re.compile(
    r"^\s*(?:<think>\s*)?(?:okay[,\s]|we need\b|let me\b|the user\b|first[,\s]|i need to\b|looking at\b)",
    re.IGNORECASE,
)


def clean_model_output(text: str | None) -> str | None:
    """Remove hidden-reasoning artifacts if a hybrid model leaks them.

    Qwen3 hybrid builds can occasionally expose a reasoning preamble even when
    thinking is disabled. Kaneki never shows that internal scratch text.
    """
    if not text:
        return None
    s = str(text).replace("\r\n", "\n")
    s = _THINK_BLOCK.sub("", s)
    # Some Ollama/model combinations have emitted the closing tag but omitted
    # the opening tag from content. In that case everything before </think>
    # is treated as hidden reasoning.
    low = s.lower()
    if "</think>" in low:
        idx = low.rfind("</think>")
        s = s[idx + len("</think>") :]
    s = s.replace("<think>", "").replace("</think>", "")
    s = s.strip()
    return s or None


class _SafeStream:
    """Streaming filter that prevents reasoning traces from reaching the GUI/TTS."""

    def __init__(self, callback):
        self.callback = callback
        self.buffer = ""
        self.decided = False
        self.suppress = False
        self.emitted = []

    def feed(self, token: str):
        if not token:
            return
        if self.suppress:
            self.buffer += token
            low = self.buffer.lower()
            if "</think>" in low:
                idx = low.find("</think>")
                rest = self.buffer[idx + len("</think>") :]
                self.buffer = ""
                self.suppress = False
                self.decided = True
                if rest:
                    self._emit(rest)
            elif len(self.buffer) > 12000:
                # Safety valve: never display a huge accidental scratchpad.
                self.buffer = ""
            return

        if not self.decided:
            self.buffer += token
            probe = self.buffer.lstrip().lower()
            if probe.startswith("<think>") or _META_PREFIX.match(self.buffer):
                self.suppress = True
                return
            # Normal answer: release quickly. 96 chars is enough to decide while
            # keeping first-token latency small.
            if len(self.buffer) >= 96 or "\n" in self.buffer or any(p in self.buffer for p in (". ", "? ", "! ")):
                chunk = self.buffer
                self.buffer = ""
                self.decided = True
                self._emit(chunk)
            return

        self._emit(token)

    def _emit(self, text):
        self.emitted.append(text)
        if self.callback is not None:
            self.callback(text)

    def finish(self):
        if self.suppress:
            # If no closing tag ever came, discard the suspected reasoning.
            self.buffer = ""
            return
        if self.buffer:
            self._emit(self.buffer)
            self.buffer = ""


class OllamaClient:
    """Small Ollama client with model detection and output hygiene."""

    def __init__(self, base_url="http://127.0.0.1:11434", model="qwen3:4b-instruct", timeout=90, keep_alive="30m"):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = int(timeout)
        self.keep_alive = keep_alive
        self.last_error = None

    def _get_json(self, path, timeout=2):
        req = urllib.request.Request(self.base_url + path, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def is_available(self):
        try:
            self._get_json("/api/tags", timeout=1.5)
            self.last_error = None
            return True
        except Exception as e:
            self.last_error = str(e)
            return False

    def installed_models(self):
        try:
            data = self._get_json("/api/tags", timeout=2)
            out = []
            for m in data.get("models", []):
                name = m.get("name") or m.get("model")
                if name:
                    out.append(name)
            self.last_error = None
            return out
        except Exception as e:
            self.last_error = str(e)
            return []

    def model_installed(self, model=None):
        target = (model or self.model).lower()
        names = [n.lower() for n in self.installed_models()]
        return any(n == target or n.startswith(target + ":") for n in names)

    def choose_first_installed(self, candidates):
        names = self.installed_models()
        low = [n.lower() for n in names]
        for candidate in candidates:
            c = candidate.lower()
            for i, n in enumerate(low):
                if n == c or n.startswith(c + ":"):
                    self.model = names[i]
                    return self.model
        return None

    def _payload(self, messages, temperature=0.35, num_ctx=8192, stream=False, think=False, num_predict=650):
        # /no_think is also appended in the assistant prompt. `think:false` is
        # kept for Ollama versions that support the native switch.
        return {
            "model": self.model,
            "messages": messages,
            "stream": bool(stream),
            "think": bool(think),
            "keep_alive": self.keep_alive,
            "options": {
                "temperature": float(temperature),
                "num_ctx": int(num_ctx),
                "top_p": 0.82,
                "top_k": 30,
                "repeat_penalty": 1.05,
                "num_predict": int(num_predict),
            },
        }

    def chat(self, messages, temperature=0.35, num_ctx=8192, think=False, num_predict=650):
        payload = self._payload(messages, temperature, num_ctx, False, think, num_predict)
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.base_url + "/api/chat", data=body, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode("utf-8"))
            text = ((data.get("message") or {}).get("content") or "").strip()
            self.last_error = None
            return clean_model_output(text)
        except urllib.error.HTTPError as e:
            try:
                detail = e.read().decode("utf-8", errors="replace")
            except Exception:
                detail = str(e)
            self.last_error = f"HTTP {e.code}: {detail[:300]}"
        except Exception as e:
            self.last_error = str(e)
        return None

    def chat_stream(self, messages, temperature=0.35, num_ctx=8192, on_token=None, think=False, num_predict=650):
        payload = self._payload(messages, temperature, num_ctx, True, think, num_predict)
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.base_url + "/api/chat", data=body, headers={"Content-Type": "application/json"}, method="POST")
        raw_parts = []
        safe = _SafeStream(on_token)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                for raw in r:
                    if not raw:
                        continue
                    data = json.loads(raw.decode("utf-8"))
                    token = ((data.get("message") or {}).get("content") or "")
                    if token:
                        raw_parts.append(token)
                        safe.feed(token)
                    if data.get("done"):
                        break
            safe.finish()
            self.last_error = None
            cleaned = clean_model_output("".join(raw_parts))
            # If the stream filter did not emit because it detected reasoning,
            # emit only the final cleaned answer now.
            emitted = "".join(safe.emitted).strip()
            if cleaned and on_token is not None and not emitted:
                on_token(cleaned)
            return cleaned
        except urllib.error.HTTPError as e:
            try:
                detail = e.read().decode("utf-8", errors="replace")
            except Exception:
                detail = str(e)
            self.last_error = f"HTTP {e.code}: {detail[:300]}"
        except Exception as e:
            self.last_error = str(e)
        return None
