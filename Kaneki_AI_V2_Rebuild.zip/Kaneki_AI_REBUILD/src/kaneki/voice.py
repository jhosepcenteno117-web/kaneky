from __future__ import annotations

import asyncio
import json
import queue
import shutil
import subprocess
import tempfile
import threading
import re
from pathlib import Path


NEURAL_PROFILES = [
    {
        "id": "assistant_es",
        "label": "Asistente elegante (español)",
        "voice": "es-ES-AlvaroNeural",
        "rate": "-8%",
        "pitch": "-8Hz",
        "volume": "+0%",
    },
    {
        "id": "assistant_latam",
        "label": "Asistente sereno (Latinoamérica)",
        "voice": "es-MX-JorgeNeural",
        "rate": "-7%",
        "pitch": "-6Hz",
        "volume": "+0%",
    },
    {
        "id": "assistant_deep",
        "label": "Asistente grave (español)",
        "voice": "es-ES-AlvaroNeural",
        "rate": "-12%",
        "pitch": "-14Hz",
        "volume": "+0%",
    },
    {
        "id": "assistant_british",
        "label": "Asistente británico (inglés)",
        "voice": "en-GB-RyanNeural",
        "rate": "-8%",
        "pitch": "-8Hz",
        "volume": "+0%",
    },
]


class VoiceEngine:
    """TTS de baja latencia.

    V2.0 usa dos etapas para Edge TTS: mientras una frase se reproduce, la siguiente
    se sintetiza en paralelo. Esto elimina gran parte de las pausas de V0.8.
    """

    def __init__(self, enabled=False, rate=0, volume=100, voice_name=None, profile="assistant_es"):
        self.enabled = bool(enabled)
        self.rate = max(-10, min(10, int(rate)))
        self.volume = max(0, min(100, int(volume)))
        self.voice_name = voice_name
        self.profile = profile
        self._queue: queue.Queue[str | None] = queue.Queue()
        self._audio_queue: queue.Queue[Path | None] = queue.Queue(maxsize=4)
        self._stop_event = threading.Event()
        self._engine = None
        self._voices = []
        self.backend = "silencio"
        self.last_error = None
        self._edge_available = False
        self._pygame = None
        self._pygame_ready = False
        self._current_player = None
        self._player_lock = threading.Lock()
        self._generation = 0
        self._init_backend()
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._play_thread = threading.Thread(target=self._playback_worker, daemon=True)
        self._thread.start()
        self._play_thread.start()

    def _init_backend(self):
        try:
            import edge_tts  # noqa: F401
            self._edge_available = True
        except Exception:
            self._edge_available = False
        # Pygame keeps one audio device open. This avoids launching a new PowerShell
        # process for every spoken fragment, which was a major source of audible gaps.
        try:
            import pygame
            pygame.mixer.init()
            self._pygame = pygame
            self._pygame_ready = True
        except Exception:
            self._pygame = None
            self._pygame_ready = False
        try:
            import pyttsx3
            self._engine = pyttsx3.init()
            self._voices = [
                {"id": getattr(v, "id", ""), "name": getattr(v, "name", "Voz"), "type": "local"}
                for v in (self._engine.getProperty("voices") or [])
            ]
            self._apply_engine_settings()
        except Exception:
            self._engine = None
            self._voices = []
        if not self._voices and (shutil.which("powershell") or shutil.which("powershell.exe")):
            self._voices = self._list_sapi_voices()
        self._refresh_backend_label()

    def _refresh_backend_label(self):
        if self.profile.startswith("assistant_") and self._edge_available:
            self.backend = "Neural (Edge) · baja latencia" + (" · audio persistente" if self._pygame_ready else "")
        elif self._engine is not None:
            self.backend = "pyttsx3 · local"
        elif shutil.which("powershell") or shutil.which("powershell.exe"):
            self.backend = "Windows SAPI · local"
        else:
            self.backend = "no disponible"

    def profiles(self): return list(NEURAL_PROFILES)
    def voices(self): return list(self._voices)
    def _powershell_exe(self): return shutil.which("powershell") or shutil.which("powershell.exe")

    def _list_sapi_voices(self):
        exe = self._powershell_exe()
        if not exe: return []
        script = ("Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                  "$s.GetInstalledVoices() | ForEach-Object { $i=$_.VoiceInfo; "
                  "[PSCustomObject]@{name=$i.Name; culture=$i.Culture.Name; gender=$i.Gender.ToString()} } | ConvertTo-Json -Compress")
        try:
            p = subprocess.run([exe,"-NoProfile","-NonInteractive","-Command",script],capture_output=True,text=True,timeout=12,
                               creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            raw=(p.stdout or "").strip()
            if not raw: return []
            data=json.loads(raw)
            if isinstance(data,dict): data=[data]
            return [{"id":x.get("name",""),"name":x.get("name","Voz"),"culture":x.get("culture",""),"gender":x.get("gender",""),"type":"local"} for x in data]
        except Exception: return []

    def _apply_engine_settings(self):
        if self._engine is None: return
        try:
            self._engine.setProperty("volume", self.volume/100.0)
            self._engine.setProperty("rate", max(90,min(270,190+self.rate*9)))
            if self.voice_name:
                for v in self._engine.getProperty("voices") or []:
                    if self.voice_name in {getattr(v,"id",""),getattr(v,"name","")}:
                        self._engine.setProperty("voice",getattr(v,"id","")); break
        except Exception: pass

    @staticmethod
    def _clean(text: str) -> str:
        text=re.sub(r"[`*_>#]","",text)
        text=re.sub(r"https?://\S+","enlace",text)
        text=re.sub(r"\s+"," ",text).strip()
        return text[:5000]

    @staticmethod
    def _split_chunks(text: str, first_max=54, max_chars=155):
        """Frases pequeñas para arrancar rápido sin cortar palabras."""
        text=text.strip()
        if not text: return []
        out=[]; buf=""; target=first_max
        # Divide conservando puntuación. Comas ayudan a que el primer audio llegue antes.
        parts=re.split(r"(?<=[.!?;:])\s+|(?<=,)\s+", text)
        for part in parts:
            part=part.strip()
            if not part: continue
            candidate=(buf+" "+part).strip() if buf else part
            if len(candidate) <= target:
                buf=candidate
                if candidate.endswith((".","?","!",";",":")) and len(candidate)>=22:
                    out.append(candidate); buf=""; target=max_chars
                continue
            if buf:
                out.append(buf); buf=""; target=max_chars
            while len(part) > target:
                cut=part.rfind(" ",0,target+1)
                if cut < 24: cut=target
                out.append(part[:cut].strip())
                part=part[cut:].strip(); target=max_chars
            buf=part
        if buf: out.append(buf)
        return [x for x in out if x]

    def set_enabled(self, enabled):
        self.enabled=bool(enabled)
        if not self.enabled: self.stop()
    def set_profile(self, profile): self.profile=profile or "local"; self._refresh_backend_label()
    def set_voice(self, voice_name): self.voice_name=voice_name or None; self._apply_engine_settings()
    def set_rate(self, rate): self.rate=max(-10,min(10,int(rate))); self._apply_engine_settings()
    def set_volume(self, volume): self.volume=max(0,min(100,int(volume))); self._apply_engine_settings()

    def say(self, text):
        if not self.enabled: return
        clean=self._clean(text)
        for chunk in self._split_chunks(clean):
            self._queue.put(chunk)

    def stop(self):
        self._generation += 1
        for q in (self._queue, self._audio_queue):
            while True:
                try:
                    item=q.get_nowait()
                    if isinstance(item, Path):
                        try: item.unlink(missing_ok=True)
                        except Exception: pass
                except queue.Empty: break
        try:
            if self._engine is not None: self._engine.stop()
        except Exception: pass
        try:
            if self._pygame_ready and self._pygame is not None:
                self._pygame.mixer.music.stop()
        except Exception: pass
        with self._player_lock:
            p=self._current_player
            if p is not None and p.poll() is None:
                try: p.terminate()
                except Exception: pass

    def close(self):
        self.enabled=False; self.stop(); self._stop_event.set()
        self._queue.put(None)
        try: self._audio_queue.put_nowait(None)
        except queue.Full: pass

    def _profile_data(self):
        return next((p for p in NEURAL_PROFILES if p["id"]==self.profile),NEURAL_PROFILES[0])

    def _render_neural(self, text, generation):
        import edge_tts
        prof=self._profile_data()
        base_rate=int(prof["rate"].replace("%",""))
        rate=max(-45,min(45,base_rate+self.rate*2))
        volume_delta=max(-50,min(50,self.volume-100))
        f=tempfile.NamedTemporaryFile(delete=False,suffix=".mp3"); out=Path(f.name); f.close()
        try:
            async def render():
                c=edge_tts.Communicate(text,prof["voice"],rate=f"{rate:+d}%",volume=f"{volume_delta:+d}%",pitch=prof["pitch"])
                await c.save(str(out))
            asyncio.run(render())
            if generation != self._generation:
                out.unlink(missing_ok=True); return None
            self.last_error=None; return out
        except Exception as e:
            self.last_error=str(e)
            try: out.unlink(missing_ok=True)
            except Exception: pass
            return None

    def _play_mp3_windows(self, path: Path):
        # Preferred path: one persistent mixer, no process spawn for every chunk.
        if self._pygame_ready and self._pygame is not None:
            try:
                self._pygame.mixer.music.load(str(path))
                self._pygame.mixer.music.play()
                while self.enabled and self._pygame.mixer.music.get_busy():
                    self._pygame.time.wait(18)
                return
            except Exception as e:
                self.last_error = str(e)
                # Fall through to the Windows MediaPlayer fallback.

        exe=self._powershell_exe()
        if not exe: raise RuntimeError("No se encontró un reproductor para el audio neuronal")
        pth=str(path).replace("'","''")
        # Fallback only. Keep the fixed wait small because process startup already adds latency.
        script=("Add-Type -AssemblyName presentationCore; $m=New-Object System.Windows.Media.MediaPlayer; "
                f"$m.Open([Uri]'{pth}'); Start-Sleep -Milliseconds 55; $m.Play(); "
                "while($m.NaturalDuration.HasTimeSpan -eq $false){Start-Sleep -Milliseconds 25}; "
                "$ms=[int]$m.NaturalDuration.TimeSpan.TotalMilliseconds; Start-Sleep -Milliseconds ($ms+45); $m.Close()")
        proc=subprocess.Popen([exe,"-NoProfile","-NonInteractive","-Command",script],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                              creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        with self._player_lock: self._current_player=proc
        try: proc.wait(timeout=180)
        finally:
            with self._player_lock:
                if self._current_player is proc: self._current_player=None

    def _speak_local(self, text):
        if self._engine is not None:
            self._apply_engine_settings(); self._engine.say(text); self._engine.runAndWait(); return True
        exe=self._powershell_exe()
        if not exe: return False
        safe_voice=(self.voice_name or "").replace("'","''")
        select=f"try{{$s.SelectVoice('{safe_voice}')}}catch{{}}; " if safe_voice else ""
        script=("Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                f"$s.Rate={self.rate}; $s.Volume={self.volume}; "+select+"$t=[Console]::In.ReadToEnd(); if($t){$s.Speak($t)}")
        subprocess.run([exe,"-NoProfile","-NonInteractive","-Command",script],input=text,text=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                       timeout=120,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)); return True

    def _worker(self):
        while not self._stop_event.is_set():
            try: text=self._queue.get(timeout=.20)
            except queue.Empty: continue
            if text is None: return
            if not self.enabled: continue
            generation=self._generation
            try:
                if self.profile.startswith("assistant_") and self._edge_available:
                    out=self._render_neural(text,generation)
                    if out is not None:
                        # Mientras este audio espera/reproduce, este hilo ya puede sintetizar el siguiente.
                        self._audio_queue.put(out)
                        continue
                # fallback local: no necesita archivo ni Internet
                self._speak_local(text)
            except Exception as e: self.last_error=str(e)

    def _playback_worker(self):
        while not self._stop_event.is_set():
            try: path=self._audio_queue.get(timeout=.20)
            except queue.Empty: continue
            if path is None: return
            try:
                if self.enabled: self._play_mp3_windows(path)
            except Exception as e: self.last_error=str(e)
            finally:
                try: path.unlink(missing_ok=True)
                except Exception: pass
