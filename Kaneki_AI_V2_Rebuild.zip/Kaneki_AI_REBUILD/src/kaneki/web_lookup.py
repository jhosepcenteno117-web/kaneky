"""Consulta factual opcional usando Wikipedia en español.

V2.0: limpia mejor la intención, rechaza resultados irrelevantes y evita respuestas
que cambien de tema por una coincidencia débil del buscador.
"""
import json
import re
import unicodedata
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

USER_AGENT = "KanekiAI/1.0 (local educational assistant)"


def _get_json(url: str, timeout: float = 5.0):
    req = Request(url, headers={"User-Agent": USER_AGENT})
    with urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def clean_query(text: str) -> str:
    q = text.strip().strip("¿?¡!.")
    patterns = [
        r"^(?:quien|quién)\s+es\s+",
        r"^(?:que|qué)\s+es\s+",
        r"^(?:que|qué)\s+sabes\s+(?:de|sobre)\s+",
        r"^(?:cuentame|cuéntame)\s+(?:de|sobre)\s+",
        r"^(?:hablame|háblame)\s+(?:de|sobre)\s+",
        r"^(?:informacion|información)\s+(?:de|sobre)\s+",
        r"^(?:de\s+que|de\s+qué)\s+trata\s+(?:el\s+|la\s+)?(?:juego|videojuego|anime|serie|pelicula|película)?\s*",
        r"^(?:explicame|explícame)\s+(?:el\s+|la\s+)?(?:juego|videojuego|anime|serie|pelicula|película)?\s*",
    ]
    for p in patterns:
        q2 = re.sub(p, "", q, flags=re.IGNORECASE).strip()
        if q2 != q:
            q = q2
            break
    # Quita artículos residuales al inicio, sin destruir nombres propios.
    q = re.sub(r"^(?:el|la|los|las)\s+", "", q, flags=re.IGNORECASE).strip()
    return q[:180]


def _relevant(query: str, title: str, snippet: str = "") -> bool:
    q = _norm(query)
    t = _norm(title)
    s = _norm(snippet)
    if not q or not t:
        return False
    q_tokens = [x for x in q.split() if len(x) > 1]
    if not q_tokens:
        return False
    # Acepta título exacto/contención o una cobertura fuerte de los tokens de la entidad.
    if q == t or q in t or t in q:
        return True
    coverage = sum(1 for tok in q_tokens if tok in t.split()) / len(q_tokens)
    if coverage >= 0.67:
        return True
    # Para nombres de varias palabras, requiere al menos dos tokens en título/snippet.
    hits = sum(1 for tok in q_tokens if tok in (t + " " + s).split())
    return hits >= min(2, len(q_tokens)) and hits / len(q_tokens) >= 0.67


def wikipedia_summary(text: str, timeout: float = 5.0):
    query = clean_query(text)
    if len(query) < 2:
        return None
    try:
        search_params = urlencode({
            "action": "query", "list": "search", "srsearch": query,
            "srlimit": 5, "format": "json", "utf8": 1,
        })
        search = _get_json("https://es.wikipedia.org/w/api.php?" + search_params, timeout)
        hits = search.get("query", {}).get("search", [])
        chosen = None
        for hit in hits:
            if _relevant(query, hit.get("title", ""), hit.get("snippet", "")):
                chosen = hit
                break
        if not chosen:
            return None
        title = chosen["title"]
        extract_params = urlencode({
            "action": "query", "prop": "extracts", "exintro": 1, "explaintext": 1,
            "redirects": 1, "titles": title, "format": "json", "utf8": 1,
        })
        data = _get_json("https://es.wikipedia.org/w/api.php?" + extract_params, timeout)
        pages = data.get("query", {}).get("pages", {})
        if not pages:
            return None
        page = next(iter(pages.values()))
        extract = " ".join((page.get("extract") or "").split())
        if len(extract) < 50:
            return None
        sentences = re.split(r"(?<=[.!?])\s+", extract)
        summary = " ".join(sentences[:3]).strip()
        if len(summary) > 700:
            summary = summary[:700].rsplit(" ", 1)[0] + "…"
        return {"title": page.get("title", title), "summary": summary}
    except (URLError, HTTPError, TimeoutError, OSError, ValueError, KeyError, json.JSONDecodeError):
        return None
