from pathlib import Path
import torch
from torch.utils.data import Dataset


class ByteBlockDataset(Dataset):
    def __init__(self, path, tokenizer, block_size=256):
        text = Path(path).read_text(encoding="utf-8")
        ids = tokenizer.encode(text)
        if len(ids) < block_size + 2:
            raise ValueError("El dataset es demasiado pequeño para el block_size configurado.")
        self.data = torch.tensor(ids, dtype=torch.long)
        self.block_size = block_size

    def __len__(self):
        return max(1, len(self.data) - self.block_size - 1)

    def __getitem__(self, i):
        x = self.data[i:i + self.block_size]
        y = self.data[i + 1:i + self.block_size + 1]
        return x, y
