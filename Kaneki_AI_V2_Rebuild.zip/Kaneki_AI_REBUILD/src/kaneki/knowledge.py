import json
import re
import unicodedata
from collections import Counter
from pathlib import Path

_STOP = {
    "el","la","los","las","un","una","unos","unas","de","del","y","o","a","en","que","me","mi","si","es","por","para","con","como","se","lo","al","más","mas","quiero","recomienda","recomiendame","recomiéndame",
    "sabes","saber","sobre","dime","decirme","puedes","podrias","podrías","trata","quien","quién"
}


def _fold(text):
    return "".join(c for c in unicodedata.normalize("NFD", text.lower()) if unicodedata.category(c) != "Mn")


_CANON = {
    "peruano": "peru", "peruana": "peru", "peruanos": "peru", "peruanas": "peru",
    "mexicano": "mexico", "mexicana": "mexico", "mexicanos": "mexico", "mexicanas": "mexico",
    "japones": "japon", "japonesa": "japon", "japoneses": "japon", "japonesas": "japon",
    "chino": "china", "china": "china", "chinos": "china", "chinas": "china",
    "plato": "comida", "platos": "comida", "comidas": "comida", "gastronomia": "comida",
    "objeto": "objeto", "objetos": "objeto", "culturas": "cultura",
}

def _tokens(text):
    words = re.findall(r"[a-záéíóúñ0-9]+", _fold(text))
    out=[]
    for w in words:
        if w in _STOP or len(w) <= 1:
            continue
        out.append(_CANON.get(w, w))
    return out


class KnowledgeBase:
    def __init__(self, path):
        self.path = Path(path)
        self.items = []
        if self.path.exists():
            with self.path.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            self.items.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        self._title_map = {_fold(x["title"]): x for x in self.items}

    def find_title_in_text(self, text):
        lower = _fold(text)
        matches = [(title, item) for title, item in self._title_map.items() if title in lower]
        if not matches:
            return None
        return max(matches, key=lambda p: len(p[0]))[1]

    def search_scored(self, query, kind=None, limit=5):
        q_tokens = _tokens(query)
        if not q_tokens:
            return []
        q = Counter(q_tokens)
        q_fold = _fold(query)
        out = []
        for item in self.items:
            if kind and item.get("kind") != kind:
                continue
            title = item.get("title", "")
            title_fold = _fold(title)
            title_tokens = set(_tokens(title))
            blob = " ".join([
                title,
                item.get("description", ""),
                " ".join(item.get("genres", [])),
                " ".join(item.get("tags", [])),
            ])
            d = Counter(_tokens(blob))
            overlap = sum(min(q[t], d[t]) for t in q)
            title_overlap = len(set(q_tokens) & title_tokens)
            # Exact entity bonus only for a complete word/phrase match, never a substring
            # ("peru" must not become an exact-title hit inside "peruanos").
            exact_title = title_fold == q_fold or re.search(r"(?<![a-z0-9])" + re.escape(title_fold) + r"(?![a-z0-9])", q_fold) is not None
            score = overlap + title_overlap * 2 + (8 if exact_title else 0)
            # Normalización simple para evitar que una sola palabra genérica gane.
            coverage = len(set(q_tokens) & set(d)) / max(1, len(set(q_tokens)))
            confidence = min(1.0, (score / 10.0) * (0.45 + 0.55 * coverage))
            if exact_title:
                confidence = max(confidence, 0.95)
            if score > 0:
                out.append((confidence, score, item))
        out.sort(key=lambda z: (z[0], z[1]), reverse=True)
        return out[:limit]

    def search(self, query, kind=None, limit=5, min_confidence=0.34):
        return [item for conf, _, item in self.search_scored(query, kind, limit) if conf >= min_confidence]

    def recommend_from(self, source_item, limit=5):
        src = set(source_item.get("tags", []) + source_item.get("genres", []))
        scored = []
        for item in self.items:
            if item["title"] == source_item["title"] or item.get("kind") != source_item.get("kind"):
                continue
            dst = set(item.get("tags", []) + item.get("genres", []))
            inter = len(src & dst)
            union = max(1, len(src | dst))
            score = inter / union
            if score > 0:
                scored.append((score, item))
        scored.sort(key=lambda z: z[0], reverse=True)
        return [x for _, x in scored[:limit]]
