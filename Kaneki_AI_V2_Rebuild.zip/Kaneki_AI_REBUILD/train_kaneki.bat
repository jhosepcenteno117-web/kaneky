@echo off
setlocal
cd /d "%~dp0"
call :find_python
if errorlevel 1 goto :no_python

"%PYEXE%" train_kaneki.py
if errorlevel 1 (
    echo.
    echo [ERROR] El entrenamiento se detuvo. Haz una captura de este mensaje.
)
pause
exit /b

:find_python
set "PYEXE="
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
    set "PYEXE=%LocalAppData%\Programs\Python\Python311\python.exe"
    exit /b 0
)
for /f "usebackq delims=" %%I in (`py -3.11 -c "import sys; print(sys.executable)" 2^>nul`) do set "PYEXE=%%I"
if defined PYEXE if exist "%PYEXE%" exit /b 0
exit /b 1

:no_python
echo [ERROR] No pude localizar Python 3.11.
echo Ruta esperada: %LocalAppData%\Programs\Python\Python311\python.exe
pause
exit /b 1
