@echo off
setlocal
cd /d "%~dp0"
call :find_python
if errorlevel 1 goto :no_python

echo === Python usado por Kaneki ===
"%PYEXE%" --version
"%PYEXE%" -c "import sys; print(sys.executable)"
echo.
echo === Pygame ===
"%PYEXE%" -c "import pygame; print('pygame', pygame.version.ver)" 2>nul || echo Pygame no esta instalado en este Python.
echo.
echo === Ollama ===
ollama list 2>nul || echo Ollama no responde desde CMD.
echo.
echo === Uso CPU/GPU de Ollama (si el modelo esta cargado) ===
ollama ps 2>nul || echo No hay un modelo cargado ahora mismo.
echo.
pause
exit /b

:find_python
set "PYEXE="
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (set "PYEXE=%LocalAppData%\Programs\Python\Python311\python.exe" & exit /b 0)
for /f "usebackq delims=" %%I in (`py -3.11 -c "import sys; print(sys.executable)" 2^>nul`) do set "PYEXE=%%I"
if defined PYEXE if exist "%PYEXE%" exit /b 0
exit /b 1
:no_python
echo No pude localizar el Python que usa Kaneki.
pause
exit /b 1
