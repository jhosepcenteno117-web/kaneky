# Kaneki AI V2.0 Rebuild

Esta compilación reemplaza la V2.0 anterior. No es un parche de respuestas concretas: cambia las partes que estaban generando los errores repetidos.

## Cambios estructurales

- **Cerebro principal:** `qwen3:4b-instruct`, variante instruct/no-thinking de 2.5 GB. El modelo híbrido anterior podía filtrar razonamiento interno en inglés.
- **Filtro de salida:** aunque se use un modelo híbrido como respaldo, Kaneki elimina bloques `<think>` y preámbulos de razonamiento antes de mostrarlos o enviarlos a TTS.
- **Búsqueda web reescrita:** ya no manda literalmente frases como `dime 5 animes...` al buscador. Extrae el tema, crea varias consultas útiles y rechaza resultados que no contienen la entidad principal.
- **Fuentes estructuradas:** los rankings de anime por año usan AniList cuando está disponible, evitando inventar posiciones desde snippets de buscador.
- **Conversación:** una pregunta nueva no hereda automáticamente el tema anterior. Solo se usa el contexto anterior cuando hay una referencia explícita como `ese juego`.
- **Hora mundial:** Huaral, Sevilla y muchas ciudades comunes tienen ruta directa; para lugares no conocidos puede usar geocodificación + `timezonefinder`.
- **Actualidad:** si una pregunta depende de datos actuales y no hay evidencia relevante, Kaneki lo dice brevemente en vez de usar conocimiento viejo como si fuera de hoy.
- **Hardware:** Ollama decide automáticamente la descarga de capas a CUDA. `check_environment.bat` muestra `ollama ps` para comprobar si el modelo está usando GPU/CPU.

## Instalación

1. Ejecuta `install.bat`.
2. Ejecuta `setup_local_brain.bat` para instalar `qwen3:4b-instruct`.
3. Ejecuta `check_environment.bat` si quieres verificar Python, Pygame, Ollama y uso GPU/CPU.
4. Abre `start_kaneki.bat`.

No hace falta borrar `qwen3:4b` ni `qwen2.5:3b`; pueden quedar como respaldo.

## Pruebas

`test_rebuild.py` comprueba tiempo por ciudad, año actual, enrutamiento web, filtrado de resultados irrelevantes, continuidad conversacional, limpieza de razonamiento interno, listas y el bug de Perú.
