from pathlib import Path
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from kaneki.assistant import KanekiAssistant
from kaneki.voice import VoiceEngine

bot = KanekiAssistant(ROOT)
voice = VoiceEngine(enabled=False, rate=-1, volume=100, profile="assistant_es")

BG = "#0d0f14"
PANEL = "#151922"
PANEL_2 = "#1b202b"
TEXT = "#eef1f6"
MUTED = "#8f9aab"
ACCENT = "#a61f2b"
ACCENT_HOVER = "#c72a38"
USER = "#80c7ff"
BOT = "#ff8791"
BORDER = "#2a303d"

app = tk.Tk()
app.title("Kaneki AI V2.0 Rebuild")
app.geometry("980x720")
app.minsize(760, 540)
app.configure(bg=BG)
app.grid_rowconfigure(1, weight=1)
app.grid_columnconfigure(0, weight=1)

# ---------- Header ----------
header = tk.Frame(app, bg=PANEL, highlightbackground=BORDER, highlightthickness=0)
header.grid(row=0, column=0, sticky="ew")
header.grid_columnconfigure(1, weight=1)

title_wrap = tk.Frame(header, bg=PANEL)
title_wrap.grid(row=0, column=0, sticky="w", padx=(20, 10), pady=14)
tk.Label(title_wrap, text="KANEKI AI", font=("Segoe UI Semibold", 20), fg=TEXT, bg=PANEL).pack(side="left")
tk.Label(title_wrap, text="  V2.0R", font=("Segoe UI", 9), fg=BOT, bg=PANEL).pack(side="left", pady=(8, 0))

status_var = tk.StringVar()
status = tk.Label(header, textvariable=status_var, font=("Segoe UI", 9), fg=MUTED, bg=PANEL)
status.grid(row=0, column=1, sticky="e", padx=(10, 20))

# ---------- Main chat ----------
main = tk.Frame(app, bg=BG)
main.grid(row=1, column=0, sticky="nsew", padx=14, pady=(12, 8))
main.grid_rowconfigure(0, weight=1)
main.grid_columnconfigure(0, weight=1)

chat = ScrolledText(
    main, wrap=tk.WORD, font=("Segoe UI", 11), state="disabled",
    bg=BG, fg=TEXT, insertbackground=TEXT, relief="flat",
    padx=18, pady=16, spacing1=2, spacing3=8, borderwidth=0,
)
chat.grid(row=0, column=0, sticky="nsew")
chat.tag_configure("user", foreground=USER, font=("Segoe UI Semibold", 10))
chat.tag_configure("bot", foreground=BOT, font=("Segoe UI Semibold", 10))
chat.tag_configure("body", foreground=TEXT, font=("Segoe UI", 11), lmargin1=0, lmargin2=0)
chat.tag_configure("meta", foreground=MUTED, font=("Segoe UI", 9))

# ---------- Toolbar: always above composer ----------
toolbar = tk.Frame(app, bg=BG)
toolbar.grid(row=2, column=0, sticky="ew", padx=16, pady=(0, 8))


def flat_button(parent, text, command, accent=False, width=None):
    b = tk.Button(
        parent, text=text, command=command, width=width,
        bg=ACCENT if accent else PANEL_2, fg=TEXT,
        activebackground=ACCENT_HOVER if accent else "#262c38",
        activeforeground=TEXT, relief="flat", bd=0,
        font=("Segoe UI Semibold" if accent else "Segoe UI", 9),
        padx=12, pady=7, cursor="hand2"
    )
    return b


def clear_chat():
    bot.clear_session()
    chat.configure(state="normal")
    chat.delete("1.0", tk.END)
    chat.configure(state="disabled")
    append("Kaneki", "Nueva conversación iniciada. Tus recuerdos persistentes siguen guardados.")


def export_chat():
    path = filedialog.asksaveasfilename(
        defaultextension=".txt", filetypes=[("Texto", "*.txt")], title="Exportar conversación"
    )
    if path:
        try:
            Path(path).write_text(chat.get("1.0", tk.END).strip(), encoding="utf-8")
        except Exception as e:
            messagebox.showerror("Kaneki", f"No pude exportar el chat:\n{e}")


def toggle_voice():
    voice.set_enabled(voice_var.get())
    voice_btn.config(text="🔊 Voz: ON" if voice.enabled else "🔇 Voz: OFF")
    update_status(False)


def stop_voice():
    voice.stop()


def voice_settings():
    win = tk.Toplevel(app)
    win.title("Configurar voz de Kaneki")
    win.geometry("560x395")
    win.resizable(False, False)
    win.configure(bg=PANEL)
    win.transient(app)
    win.grab_set()

    tk.Label(win, text="Voz de Kaneki", bg=PANEL, fg=TEXT, font=("Segoe UI Semibold", 16)).pack(anchor="w", padx=22, pady=(20, 6))
    tk.Label(win, text="Elige un perfil neuronal tipo asistente o una voz local de Windows. Si la voz neuronal falla, Kaneki usa la voz local automáticamente.", bg=PANEL, fg=MUTED, font=("Segoe UI", 9), wraplength=470, justify="left").pack(anchor="w", padx=22, pady=(0, 14))

    profiles = voice.profiles()
    profile_labels = [p.get("label", p.get("id")) for p in profiles] + ["Voz local de Windows"]
    prow = tk.Frame(win, bg=PANEL)
    prow.pack(fill="x", padx=22, pady=(0, 10))
    tk.Label(prow, text="Perfil", bg=PANEL, fg=TEXT, width=12, anchor="w").pack(side="left")
    profile_combo = ttk.Combobox(prow, values=profile_labels, state="readonly", width=40)
    profile_combo.pack(side="left", fill="x", expand=True)
    pidx = next((i for i,p in enumerate(profiles) if p.get("id")==voice.profile), len(profiles))
    profile_combo.current(pidx if pidx < len(profile_labels) else 0)

    voices = voice.voices()
    names = [v.get("name") or v.get("id") or "Voz" for v in voices]
    row = tk.Frame(win, bg=PANEL)
    row.pack(fill="x", padx=22)
    tk.Label(row, text="Voz local", bg=PANEL, fg=TEXT, width=12, anchor="w").pack(side="left")
    voice_combo = ttk.Combobox(row, values=names, state="readonly", width=40)
    voice_combo.pack(side="left", fill="x", expand=True)
    if names:
        current = 0
        if voice.voice_name:
            for i, v in enumerate(voices):
                if voice.voice_name in {v.get("name"), v.get("id")}:
                    current = i; break
        voice_combo.current(current)

    rate_var = tk.IntVar(value=voice.rate)
    vol_var = tk.IntVar(value=voice.volume)

    r2 = tk.Frame(win, bg=PANEL); r2.pack(fill="x", padx=22, pady=(18, 0))
    tk.Label(r2, text="Velocidad", bg=PANEL, fg=TEXT, width=12, anchor="w").pack(side="left")
    tk.Scale(r2, from_=-10, to=10, orient="horizontal", variable=rate_var, bg=PANEL, fg=TEXT, troughcolor=PANEL_2, highlightthickness=0, length=330).pack(side="left")

    r3 = tk.Frame(win, bg=PANEL); r3.pack(fill="x", padx=22, pady=(8, 0))
    tk.Label(r3, text="Volumen", bg=PANEL, fg=TEXT, width=12, anchor="w").pack(side="left")
    tk.Scale(r3, from_=0, to=100, orient="horizontal", variable=vol_var, bg=PANEL, fg=TEXT, troughcolor=PANEL_2, highlightthickness=0, length=330).pack(side="left")

    def apply_and_preview(close=False):
        psel = profile_combo.current()
        if 0 <= psel < len(profiles):
            voice.set_profile(profiles[psel].get("id"))
        else:
            voice.set_profile("local")
        if names:
            idx = max(0, voice_combo.current())
            selected = voices[idx]
            voice.set_voice(selected.get("id") or selected.get("name"))
        voice.set_rate(rate_var.get())
        voice.set_volume(vol_var.get())
        was = voice.enabled
        voice.set_enabled(True)
        voice.say("Hola. Soy Kaneki. Esta es mi voz actual.")
        if not was:
            app.after(2500, lambda: voice.set_enabled(False) if not voice_var.get() else None)
        if close:
            win.destroy()

    buttons = tk.Frame(win, bg=PANEL); buttons.pack(fill="x", padx=22, pady=20)
    flat_button(buttons, "Probar voz", lambda: apply_and_preview(False)).pack(side="left")
    flat_button(buttons, "Guardar", lambda: apply_and_preview(True), accent=True).pack(side="right")

    if not names:
        voice_combo.set("No se detectaron voces instaladas")
        voice_combo.configure(state="disabled")

flat_button(toolbar, "Nueva conversación", clear_chat).pack(side="left")
flat_button(toolbar, "Exportar", export_chat).pack(side="left", padx=(8, 0))
voice_var = tk.BooleanVar(value=False)
voice_btn = flat_button(toolbar, "🔇 Voz: OFF", lambda: (voice_var.set(not voice_var.get()), toggle_voice()))
voice_btn.pack(side="left", padx=(8, 0))
flat_button(toolbar, "⚙ Configurar voz", voice_settings).pack(side="left", padx=(8, 0))
flat_button(toolbar, "■ Detener voz", stop_voice).pack(side="left", padx=(8, 0))

tk.Label(toolbar, text=f"TTS: {voice.backend}", bg=BG, fg=MUTED, font=("Segoe UI", 8)).pack(side="right", padx=4)

# ---------- Composer: fixed at bottom, never disappears ----------
composer_outer = tk.Frame(app, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
composer_outer.grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 14))
composer_outer.grid_columnconfigure(0, weight=1)

entry = tk.Text(
    composer_outer, height=3, wrap=tk.WORD, font=("Segoe UI", 11),
    bg=PANEL, fg=TEXT, insertbackground=TEXT, relief="flat", bd=0,
    padx=13, pady=10, undo=True
)
entry.grid(row=0, column=0, sticky="ew", padx=(4, 8), pady=4)

send_btn = flat_button(composer_outer, "Enviar", lambda: ask(), accent=True, width=10)
send_btn.grid(row=0, column=1, sticky="ns", padx=(0, 8), pady=8)

hint = tk.Label(
    composer_outer, text="Enter = enviar  •  Shift+Enter = nueva línea  •  /ayuda = comandos",
    bg=PANEL, fg=MUTED, font=("Segoe UI", 8)
)
hint.grid(row=1, column=0, columnspan=2, sticky="w", padx=14, pady=(0, 7))


def append(who, text):
    chat.configure(state="normal")
    tag = "user" if who == "Tú" else "bot"
    chat.insert(tk.END, f"{who}\n", tag)
    chat.insert(tk.END, f"{text}\n\n", "body")
    chat.configure(state="disabled")
    chat.see(tk.END)


def begin_streamed_answer():
    chat.configure(state="normal")
    chat.insert(tk.END, "Kaneki\n", "bot")
    chat.configure(state="disabled")
    chat.see(tk.END)


def append_stream_token(token):
    chat.configure(state="normal")
    chat.insert(tk.END, token, "body")
    chat.configure(state="disabled")
    chat.see(tk.END)


def finish_streamed_answer():
    chat.configure(state="normal")
    chat.insert(tk.END, "\n\n", "body")
    chat.configure(state="disabled")
    chat.see(tk.END)


def update_status(busy=False):
    if busy:
        status_var.set("Pensando…")
    else:
        device = "GPU/CUDA" if bot.device == "cuda" else "CPU"
        st = bot.local_llm_status()
        if st.get("available") and st.get("installed"):
            model = f"LLM local: {st.get('model')}"
        elif st.get("available"):
            model = f"Ollama listo · falta {st.get('model')}"
        else:
            model = "modo híbrido · Ollama no detectado (ejecuta setup_local_brain.bat)"
        v = " · voz ON" if voice.enabled else ""
        status_var.set(f"{device} · {model}{v}")


def set_busy(busy):
    send_btn.config(state="disabled" if busy else "normal")
    entry.config(state="disabled" if busy else "normal")
    update_status(busy)
    if not busy:
        entry.focus_set()


def local_command(q):
    cmd = q.strip().lower()
    if cmd == "/ayuda":
        return (
            "Comandos rápidos:\n"
            "• /voz — activa o desactiva la voz.\n"
            "• /memoria — muestra los recuerdos guardados.\n"
            "• /limpiar — inicia una conversación nueva.\n"
            "• /ayuda — muestra esta ayuda.\n\n"
            "También puedes escribir: 'recuerda que me gusta...' para guardar un recuerdo."
        )
    if cmd == "/memoria":
        return bot.memory.summary()
    if cmd == "/limpiar":
        bot.clear_session()
        return "Conversación de esta sesión limpiada. La memoria persistente se conserva."
    if cmd == "/voz":
        voice_var.set(not voice.enabled)
        toggle_voice()
        return "Voz activada." if voice.enabled else "Voz desactivada."
    return None


def ask():
    if str(entry.cget("state")) == "disabled":
        return
    q = entry.get("1.0", "end-1c").strip()
    if not q:
        return
    entry.delete("1.0", tk.END)
    append("Tú", q)

    cmd_answer = local_command(q)
    if cmd_answer is not None:
        append("Kaneki", cmd_answer)
        voice.say(cmd_answer)
        return

    set_busy(True)

    def worker():
        streamed = {"started": False, "voice_buffer": "", "voice_started": False}

        def on_token(token):
            if not streamed["started"]:
                streamed["started"] = True
                app.after(0, begin_streamed_answer)
            app.after(0, lambda t=token: append_stream_token(t))

            # Empieza a hablar mientras el LLM todavía genera la respuesta.
            # Se envían frases completas para evitar cortar palabras.
            streamed["voice_buffer"] += token
            buf = streamed["voice_buffer"]
            # V2.0: primera frase pronto; después usa bloques mayores para mantener fluidez.
            first = not streamed.get("voice_started", False)
            min_chars = 18 if first else 72
            max_chars = 54 if first else 175
            punctuation = (".", "?", "!", ":", ";", ",") if first else (".", "?", "!", ":", ";")
            if len(buf) >= min_chars and (buf.rstrip().endswith(punctuation) or len(buf) >= max_chars):
                voice.say(buf.strip())
                streamed["voice_buffer"] = ""
                streamed["voice_started"] = True

        try:
            ans = bot.reply(q, on_token=on_token)
        except Exception as e:
            ans = f"Ocurrió un error interno, pero Kaneki sigue abierto: {e}"

        def done():
            if streamed["started"]:
                finish_streamed_answer()
                tail = streamed["voice_buffer"].strip()
                if tail:
                    voice.say(tail)
            else:
                append("Kaneki", ans)
                voice.say(ans)
            set_busy(False)

        app.after(0, done)

    threading.Thread(target=worker, daemon=True).start()


def on_enter(event):
    if event.state & 0x0001:  # Shift
        return None
    ask()
    return "break"

entry.bind("<Return>", on_enter)


def on_close():
    try:
        voice.close()
    finally:
        app.destroy()

app.protocol("WM_DELETE_WINDOW", on_close)

update_status(False)
append(
    "Kaneki",
    "Kaneki V2.0 Rebuild está listo. Usa un modelo instruct sin razonamiento visible, contexto temporal real y búsqueda web filtrada cuando necesita datos actuales."
)
entry.focus_set()
app.mainloop()
