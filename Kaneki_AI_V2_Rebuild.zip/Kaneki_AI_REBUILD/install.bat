@echo off
setlocal
cd /d "%~dp0"

call :find_python
if errorlevel 1 goto :no_python

echo.
echo [Kaneki] Python detectado:
"%PYEXE%" --version
if errorlevel 1 goto :no_python

echo.
echo [Kaneki] Comprobando pip...
"%PYEXE%" -m ensurepip --upgrade >nul 2>&1

echo.
echo [Kaneki] Actualizando pip...
"%PYEXE%" -m pip install --upgrade pip
if errorlevel 1 goto :pip_error

echo.
echo [Kaneki] Instalando dependencias...
"%PYEXE%" -m pip install -r requirements.txt
if errorlevel 1 goto :pip_error

echo.
echo ==============================================
echo  Instalacion de Kaneki completada correctamente.
echo  Ahora ejecuta start_kaneki.bat
echo ==============================================
pause
exit /b 0

:find_python
set "PYEXE="

if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
    set "PYEXE=%LocalAppData%\Programs\Python\Python311\python.exe"
    exit /b 0
)

for /f "usebackq delims=" %%I in (`py -3.11 -c "import sys; print(sys.executable)" 2^>nul`) do set "PYEXE=%%I"
if defined PYEXE if exist "%PYEXE%" exit /b 0

for /f "usebackq delims=" %%I in (`where python 2^>nul`) do (
    if not defined PYEXE set "PYEXE=%%I"
)
if defined PYEXE if exist "%PYEXE%" exit /b 0

exit /b 1

:no_python
echo.
echo [ERROR] No pude localizar Python 3.11.
echo La ruta esperada es:
echo %LocalAppData%\Programs\Python\Python311\python.exe
echo.
echo Si Python esta instalado, reinicia Windows y vuelve a intentarlo.
pause
exit /b 1

:pip_error
echo.
echo [ERROR] La instalacion de dependencias fallo.
echo Haz una captura de esta ventana y enviala para revisarla.
pause
exit /b 1
