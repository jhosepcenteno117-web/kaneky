from pathlib import Path
import datetime
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))

from kaneki.assistant import KanekiAssistant
from kaneki.tools import current_year_answer, date_time_answer, _extract_time_place
from kaneki.local_llm import clean_model_output, _SafeStream
from kaneki.web_search import build_search_queries, subject_tokens, SearchResult, _relevant
from kaneki.current_facts import anime_ranking_request

checks=[]
def ok(name, cond, detail=''):
    assert cond, f'{name}: {detail}'
    checks.append(name)

bot = KanekiAssistant(ROOT)

# 1) Time/date are deterministic and location-aware.
y = current_year_answer('dime en que año estamos')
ok('year-current', str(datetime.datetime.now().year) in (y or ''), y)
for query, expected in [
    ('a que hora es en Huaral', 'Huaral'),
    ('a que hora es en Sevilla', 'Sevilla'),
    ('que hora es en España', 'España peninsular'),
    ('que hora es en Japón', 'Japón'),
]:
    ans = date_time_answer(query)
    ok('time-'+expected, ans and expected in ans, ans)
ok('extract-place', _extract_time_place('a que hora es en Londres') == 'londres')

# 2) Search queries are based on the subject, not command words like "dime".
q1 = build_search_queries('dime el ultimo iphone que salio', datetime.datetime.now().year)
ok('iphone-query', any('iPhone' in q and 'apple.com' in q for q in q1), q1)
q2 = build_search_queries('dime 5 animes mas valorados del 2026', 2026)
ok('anime-query', any('MyAnimeList' in q or 'AniList' in q for q in q2), q2)
ok('stopword-dime-removed', 'dime' not in subject_tokens('dime 5 animes mas valorados del 2026'))
ok('reject-dime-coin', not _relevant('dime 5 animes mas valorados del 2026', SearchResult('Dime (United States coin)', 'US coin', 'https://wikipedia.org/dime')))
ok('accept-anime-result', _relevant('dime 5 animes mas valorados del 2026', SearchResult('Top Anime 2026', 'anime scores', 'https://myanimelist.net/topanime.php')))

# 3) New unrelated factoids do not inherit previous topic/web routing.
bot.last_topic='iPhone'
bot.history=[('cual es el ultimo iphone','respuesta')]
ok('messi-no-web', not bot._should_use_web('quien es Lionel Messi'))
ok('latest-still-web', bot._should_use_web('cual es el ultimo iphone que salio'))
ok('followup-release-web', bot._should_use_web('en que año salio ese juego'))

# 4) Thinking/scratchpad never reaches UI.
raw='<think>Okay, the user is asking. Let me reason for a while.</think> Lionel Messi es un futbolista argentino.'
ok('strip-think-block', clean_model_output(raw).startswith('Lionel Messi'), clean_model_output(raw))
raw2='Okay, the user is asking for the latest iPhone.\nMore internal reasoning.\n</think>\nEl modelo más reciente verificado es X.'
ok('strip-orphan-think', clean_model_output(raw2).startswith('El modelo'), clean_model_output(raw2))
out=[]
f=_SafeStream(out.append)
for chunk in ['<think>','Internal ','reasoning','</think>','Respuesta final.']:
    f.feed(chunk)
f.finish()
ok('stream-no-reasoning', ''.join(out).strip() == 'Respuesta final.', out)

# 5) Prompt is Spanish-final-only and current date is authoritative.
prompt=bot._system_prompt('quien es Lionel Messi', [], '')
ok('prompt-final-only', 'SOLO con la respuesta final' in prompt)
ok('prompt-no-analysis', 'Nunca muestres razonamiento interno' in prompt)
ok('prompt-year', str(datetime.datetime.now().year) in prompt)
ok('prompt-no-topic-drag', 'arrastres un tema anterior' in prompt)

# 6) Structured dynamic ranking route.
r=anime_ranking_request('dime 5 animes mas valorados del 2026')
ok('anime-ranking-parser', r == (2026,5), r)

# 7) Lists and old Peru hijack protections remain.
ok('peru-list-count', bot._requested_count('dime 10 platos típicos peruanos') == 10)
ok('peru-not-local-hijack', bot._strict_local_fallback('dime 10 platos típicos peruanos') is None)

print(f'REBUILD TESTS OK - {len(checks)} checks')
