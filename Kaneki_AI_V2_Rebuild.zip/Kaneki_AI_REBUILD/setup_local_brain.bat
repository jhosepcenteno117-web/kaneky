@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo  Kaneki AI V2.0 Rebuild - Cerebro local estable
echo =====================================================
echo.
where ollama >nul 2>&1
if errorlevel 1 goto :no_ollama

echo [Kaneki] Ollama encontrado.
echo [Kaneki] Descargando qwen3:4b-instruct (aprox. 2.5 GB)...
echo Es la variante instruct/no-thinking: evita mostrar razonamiento interno
echo y mantiene un tamano adecuado para una RTX 3050 de 4 GB.
echo.
ollama pull qwen3:4b-instruct
if errorlevel 1 goto :pull_error

echo.
echo =====================================================
echo  Listo. Cerebro principal: qwen3:4b-instruct
 echo  El modelo anterior puede quedarse instalado como respaldo.
echo  Ahora abre start_kaneki.bat
 echo =====================================================
pause
exit /b 0

:no_ollama
echo [ERROR] No encontre Ollama instalado o no esta en PATH.
echo Abre Ollama y vuelve a ejecutar este archivo.
pause
exit /b 1

:pull_error
echo [ERROR] No pude descargar qwen3:4b-instruct.
echo Comprueba Internet y que Ollama este abierto.
pause
exit /b 1
